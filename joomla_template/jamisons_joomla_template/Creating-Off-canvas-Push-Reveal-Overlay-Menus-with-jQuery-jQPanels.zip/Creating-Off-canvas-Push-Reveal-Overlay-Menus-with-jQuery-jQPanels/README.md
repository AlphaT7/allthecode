jQPanels
========

Push, Reveal and Overlay panels using jQuery.Jquery Mobile is quite useful, no doubt about that but believe me its quite heavy and increases loading time and I hate the CSS over riding issue of jQuery Mobile, it sucks. So I created panels with jQuery to get rid off mobile stuff. Its an easy solution and works like jQuery Mobile.
